import{createContext as t,use as e}from"react";export const UniwindContext=t({scopedTheme:null}),useUniwindContext=()=>e(UniwindContext);UniwindContext.displayName="UniwindContext";
