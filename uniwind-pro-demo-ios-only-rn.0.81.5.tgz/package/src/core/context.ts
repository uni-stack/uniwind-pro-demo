import{createContext,use}from"react";export const UniwindContext=createContext({scopedTheme:null}),useUniwindContext=()=>use(UniwindContext);UniwindContext.displayName="UniwindContext";
