const n=/(?<![#\w.-])[+-]?(?:\d*\.\d+|\d+)(?![\w-])/g,o=/undefined/g;export const parseBoxShadow=e=>e.replace(n,d=>`${d}px`).replace(o,"");
