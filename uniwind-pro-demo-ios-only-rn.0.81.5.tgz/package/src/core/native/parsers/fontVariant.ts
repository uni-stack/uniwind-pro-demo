export const parseFontVariant=t=>t.split(" ").filter(n=>n!=="undefined");
