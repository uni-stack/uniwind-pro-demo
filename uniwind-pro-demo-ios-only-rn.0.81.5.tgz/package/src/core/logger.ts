export class Logger{static log(n){console.log(`Uniwind - ${n}`)}static error(n){console.error(`Uniwind - ${n}`)}static warn(n){console.warn(`Uniwind - ${n}`)}}
