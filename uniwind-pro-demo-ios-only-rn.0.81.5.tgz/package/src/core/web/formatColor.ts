import{formatHex as t,formatHex8 as a,parse as e}from"culori";export const formatColor=o=>{const r=e(o);return r?r.alpha!==void 0&&r.alpha!==1?a(r):t(r):o};
