import{parse as e}from"culori";import{formatColor as o}from"./formatColor";export const parseCSSValue=t=>{const r=t.trim();return isNaN(Number(r))&&e(r)!==void 0?o(r):r};
