import{Platform as o}from"react-native";export const isAndroid=o.OS==="android";
