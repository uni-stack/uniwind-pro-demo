import{useMemo}from"react";import{UniwindContext}from"../../core/context";export const ScopedTheme=({theme,children})=>{const value=useMemo(()=>({scopedTheme:theme}),[theme]);return<UniwindContext.Provider value={value}>
            <div className={theme}style={{display:"contents"}}>
                {children}
            </div>
        </UniwindContext.Provider>};
