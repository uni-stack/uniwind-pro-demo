import{useMemo}from"react";import{UniwindContext}from"../../core/context";export const ScopedTheme=({theme,children})=>{const value=useMemo(()=>({scopedTheme:theme}),[theme]);return<UniwindContext.Provider value={value}>
            {children}
        </UniwindContext.Provider>};
