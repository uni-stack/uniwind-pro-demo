export const forwardRef=(localRef,props)=>ref=>{if(ref instanceof HTMLElement&&(localRef.current=ref),typeof props.ref=="function")return props.ref(ref);props.ref&&(props.ref.current=ref)};
