export const forwardRef=(f,e)=>r=>{if(r instanceof HTMLElement&&(f.current=r),typeof e.ref=="function")return e.ref(r);e.ref&&(e.ref.current=r)};
