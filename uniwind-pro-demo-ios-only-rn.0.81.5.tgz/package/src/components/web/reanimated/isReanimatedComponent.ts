export const isReanimatedComponent=n=>n?.includes("uw-entering")||n?.includes("uw-exiting")||n?.includes("uw-layout")||!1;
