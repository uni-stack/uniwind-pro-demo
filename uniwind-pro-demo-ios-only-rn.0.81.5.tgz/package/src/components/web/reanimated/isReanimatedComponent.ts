export const isReanimatedComponent=className=>className?.includes("uw-entering")||className?.includes("uw-exiting")||className?.includes("uw-layout")||!1;
