export const toKebabCase=e=>e.replace(/[A-Z]/g,r=>`-${r.toLowerCase()}`);const n=e=>Object.entries(e).map(([r,t])=>[`@utility ${r} {`,...Object.entries(t).map(([o,i])=>`  ${toKebabCase(o)}: ${i};`),"}",""].join(`
`)).join(`
`),s={"border-continuous":{borderCurve:"continuous"},"border-circular":{borderCurve:"circular"}};export const EXTRA_UTILITIES_CSS=n(s);
