export const toKebabCase=str=>str.replace(/[A-Z]/g,letter=>`-${letter.toLowerCase()}`);const generateExtraUtilities=map=>Object.entries(map).map(([name,style])=>[`@utility ${name} {`,...Object.entries(style).map(([key,value])=>`  ${toKebabCase(key)}: ${value};`),"}",""].join(`
`)).join(`
`),EXTRA_UTILITIES_MAP={"border-continuous":{borderCurve:"continuous"},"border-circular":{borderCurve:"circular"}};export const EXTRA_UTILITIES_CSS=generateExtraUtilities(EXTRA_UTILITIES_MAP);
