const variants=["ios","android","web","native","tv","android-tv","apple-tv"],generateCSSForVariants=()=>{let css="";return variants.forEach(variant=>{css+=`@custom-variant ${variant} (${variant==="web"?"html &":`@media ${variant}`});
`}),css};export const VARIANTS_CSS=generateCSSForVariants();
