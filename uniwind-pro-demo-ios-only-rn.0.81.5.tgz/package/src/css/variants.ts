const n=["ios","android","web","native","tv","android-tv","apple-tv"],o=()=>{let e="";return n.forEach(t=>{e+=`@custom-variant ${t} (${t==="web"?"html &":`@media ${t}`});
`}),e};export const VARIANTS_CSS=o();
