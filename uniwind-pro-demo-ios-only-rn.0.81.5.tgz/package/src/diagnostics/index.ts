export*from"./diagnostics";
