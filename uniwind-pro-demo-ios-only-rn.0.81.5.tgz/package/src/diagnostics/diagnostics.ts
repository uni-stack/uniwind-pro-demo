export const enableDiagnostics=o=>{};
