export const enableDiagnostics=config=>{};
