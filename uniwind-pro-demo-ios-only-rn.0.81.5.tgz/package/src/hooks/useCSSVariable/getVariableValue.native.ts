import{UniwindStore as r}from"../../core/native";import{UniwindRuntime as t}from"../../specs";export const getVariableValue=(e,n)=>r.vars[n.scopedTheme??t.current.currentThemeName]?.[e];
