export*from"./useCSSVariable";
