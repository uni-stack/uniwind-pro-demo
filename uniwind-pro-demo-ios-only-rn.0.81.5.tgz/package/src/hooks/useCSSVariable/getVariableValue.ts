import{getWebVariable as e}from"../../core/web";export const getVariableValue=e;
