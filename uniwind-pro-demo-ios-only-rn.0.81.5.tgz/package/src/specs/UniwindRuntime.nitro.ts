import { HybridObject } from 'react-native-nitro-modules'
import { ComponentContext, ComponentState, ThemeName } from '../core/types'
import { RuntimeChangeSource, StyleDependency } from './NativePlatform.nitro'
import { Dimensions, Insets } from './types'

type ColorScheme = 'light' | 'dark'
type Orientation = 'portrait' | 'landscape'

export type UniwindRuntimeCurrent = {
    colorScheme: ColorScheme
    hasAdaptiveThemes: boolean
    currentThemeName: string
    screen: Dimensions
    insets: Insets
    orientation: Orientation
    pixelRatio: number
    fontScale: number
    rtl: boolean
    rem: number
    hairlineWidth: number
}

export type ResolveClassNamesPayload = {
    classNames: Array<[string, ComponentState | undefined, Record<string, string | boolean> | undefined, ComponentContext]>
    accents: Array<[string, string, ComponentState | undefined, Record<string, string | boolean> | undefined, ComponentContext]>
    runtime: UniwindRuntimeCurrent
    dependencies: Array<StyleDependency>
    changeSource: RuntimeChangeSource
}

export interface UniwindRuntime extends HybridObject<{ ios: 'c++'; android: 'c++' }> {
    readonly current: UniwindRuntimeCurrent

    registerThemes(themeNames: ReadonlyArray<string>): void
    onCSSVariablesChanged(forTheme: string): void
    onResolveClassNames(
        listener: (payload: ResolveClassNamesPayload) => void,
    ): () => void
    onDependencyChange(
        listener: (dependencies: Array<StyleDependency>) => void,
        dependencies?: Array<StyleDependency>,
    ): () => void
}

export type UniwindRuntimeCurrentPublic = Omit<UniwindRuntimeCurrent, 'currentThemeName'> & {
    currentThemeName: ThemeName
}

export type UniwindRuntimePublic = Omit<UniwindRuntime, 'current'> & {
    current: UniwindRuntimeCurrentPublic
}
