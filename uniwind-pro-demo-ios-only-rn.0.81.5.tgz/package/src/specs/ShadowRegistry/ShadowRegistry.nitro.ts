import { CustomType, HybridObject } from 'react-native-nitro-modules'
import { ComponentContext, ComponentState } from '../../core/types'
import { StyleDependency } from '../NativePlatform.nitro'
import { AnyObject } from '../types'
import { UniwindDiagnostics } from '../UniwindDiagnostics.nitro'
import { FollyStyle } from './FollyStyle.nitro'
import { ShadowNodeHandle } from './ShadowNodeHandle.nitro'

export type AccentMeta = ListMeta | {}

type ListMeta = {
    hasListFooterComponent: boolean
    hasListHeaderComponent: boolean
}

type Meta = CustomType<
    AnyObject,
    'margelo::nitro::uniwind::SharedFolly',
    { include: 'JSIConverter+SharedFolly.hpp' }
>

export type Accent = {
    handle: ShadowNodeHandle
    className: string
    accentKey: string
    dependencies: Array<StyleDependency>
    meta: Meta
}

export interface ShadowRegistry extends HybridObject<{ ios: 'c++'; android: 'c++' }> {
    link(
        shadowNode: ShadowNodeHandle,
        className: string,
        componentName: string,
        dependencies: Array<StyleDependency>,
        accents: Array<Accent>,
        inlineStyle: FollyStyle,
        state: ComponentState | undefined,
        dataAttributes: Record<string, string | boolean> | undefined,
        context: ComponentContext,
    ): void
    unlink(shadowNode: ShadowNodeHandle): void
    suspend(shadowNode: ShadowNodeHandle): void
    updateShadowTree(
        mutations: Record<string, FollyStyle>,
        accentMutations: Record<string, FollyStyle>,
    ): boolean
    enableDiagnostics(instance: UniwindDiagnostics): void
}
