import { CustomType, HybridObject } from 'react-native-nitro-modules'
import { AnyObject } from '../types'

type FollyDynamic = CustomType<
    AnyObject,
    'margelo::nitro::uniwind::SharedFolly',
    { include: 'JSIConverter+SharedFolly.hpp' }
>

export interface FollyStyle extends HybridObject<{ ios: 'c++'; android: 'c++' }> {
    fromJSObject(style: FollyDynamic): void
    getStyle(): FollyDynamic
}
