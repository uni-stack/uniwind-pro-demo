import { CustomType, HybridObject } from 'react-native-nitro-modules'
import { AnyObject } from '../types'

type ShadowNode = CustomType<
    AnyObject,
    'std::shared_ptr<const ShadowNode>',
    { include: 'JSIConverter+ShadowNode.hpp' }
>

export interface ShadowNodeHandle extends HybridObject<{ ios: 'c++'; android: 'c++' }> {
    fromRef(ref: ShadowNode): void
    fromTag(tag: number): void
}
