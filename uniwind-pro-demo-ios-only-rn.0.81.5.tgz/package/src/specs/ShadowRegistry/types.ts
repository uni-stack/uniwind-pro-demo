export type ShadowNode = {
    __hostObjectShadowNodeWrapper: any
}

type StateNode = {
    node?: ShadowNode
}

export type ViewHandle = {
    __nativeTag: number
    __internalInstanceHandle?: {
        stateNode?: StateNode
        elementType?: string
        tag: number
    }
    getInnerViewRef?: () => {
        __nativeTag: number
    }
    getScrollResponder?: () => {
        getNativeScrollRef?: () => {
            __nativeTag: number
            __internalInstanceHandle?: {
                stateNode?: StateNode
            }
        }
        getInnerViewRef?: () => {
            __nativeTag: number
        }
        _innerView?: {
            nativeInstance?: {
                __internalInstanceHandle?: {
                    stateNode?: StateNode
                }
            }
        }
    }
    getNativeScrollRef?: () => {
        __internalInstanceHandle?: {
            stateNode?: StateNode
        }
        getInnerViewRef?: () => {
            __internalInstanceHandle?: {
                stateNode?: StateNode
            }
        }
        __nativeTag: number
    }
    _viewRef?: {
        __internalInstanceHandle?: {
            stateNode?: StateNode
        }
    }
    viewRef?: {
        current?: {
            __internalInstanceHandle?: {
                stateNode?: StateNode
            }
        }
    }
    _nativeRef?: {
        __internalInstanceHandle?: {
            stateNode?: StateNode
        }
    }
    _reactInternals?: {
        child?: {
            child?: {
                stateNode?: StateNode
            }
        }
    }
}
