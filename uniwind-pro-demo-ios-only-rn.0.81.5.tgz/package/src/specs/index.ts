import './NativeTurboUniwind'
import { NitroModules } from 'react-native-nitro-modules'
import { PublicHybrid } from '../types'
import { RuntimeChangeSource, StyleDependency, ThemeTransitionPreset } from './NativePlatform.nitro'
import {
    Accent,
    AccentMeta,
    FollyStyle as FollyStyleSpec,
    ShadowNode,
    ShadowNodeHandle as ShadowNodeHandleSpec,
    ShadowRegistry as ShadowRegistrySpec,
    ViewHandle,
} from './ShadowRegistry'
import { AnyObject } from './types'
import { UniwindConfig as UniwindConfigSpec, UniwindConfigPublic } from './UniwindConfig.nitro'
import type { UniwindDiagnostics as UniwindDiagnosticsSpec } from './UniwindDiagnostics.nitro'
import type {
    UniwindRuntime as UniwindRuntimeSpec,
    UniwindRuntimeCurrent,
    UniwindRuntimeCurrentPublic,
    UniwindRuntimePublic,
} from './UniwindRuntime.nitro'

// public API
export const Uniwind = NitroModules
    .createHybridObject<UniwindConfigSpec>('UniwindConfig') as PublicHybrid<UniwindConfigPublic>

export const UniwindRuntime = NitroModules
    .createHybridObject<UniwindRuntimeSpec>('UniwindRuntime') as PublicHybrid<UniwindRuntimePublic>

export const ShadowRegistry = NitroModules
    .createHybridObject<ShadowRegistrySpec>('ShadowRegistry')

export const UniwindDiagnostics = NitroModules
    .createHybridObject<UniwindDiagnosticsSpec>('UniwindDiagnostics')

export const FollyStyle = () =>
    NitroModules
        .createHybridObject<FollyStyleSpec>('FollyStyle')

export const ShadowNodeHandle = () =>
    NitroModules
        .createHybridObject<ShadowNodeHandleSpec>('ShadowNodeHandle')

export * from './types'
export {
    RuntimeChangeSource,
    StyleDependency,
    ThemeTransitionPreset,
    UniwindRuntimeCurrent,
    UniwindRuntimeCurrentPublic,
}
export type {
    Accent,
    AccentMeta,
    AnyObject,
    ShadowNode,
    ShadowNodeHandleSpec,
    ViewHandle,
}
