import { HybridObject } from 'react-native-nitro-modules'
import { FollyStyle } from './ShadowRegistry'

export interface DiagnosticUpdate {
    tag: number
    componentName: string
    isNative: boolean
    style: FollyStyle
}

export interface UniwindDiagnostics extends HybridObject<{ ios: 'c++'; android: 'c++' }> {
    onShadowNodeRegistered(listener: (tag: number, className: string, shadowNodesCount: number) => void): void
    onShadowNodeUnregistered(listener: (tag: number, shadowNodesCount: number) => void): void
    onShadowTreeUpdate(listener: (updates: Array<DiagnosticUpdate>) => void): void
}
