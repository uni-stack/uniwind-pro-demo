import { HybridObject } from 'react-native-nitro-modules'
import type { ThemeName } from '../core/types'
import { ThemeTransitionPreset } from './NativePlatform.nitro'

export type ThemeTransition = {
    preset: ThemeTransitionPreset
}

export interface UniwindConfig extends HybridObject<{ ios: 'c++'; android: 'c++' }> {
    readonly hasAdaptiveThemes: boolean
    readonly currentTheme: string

    setTheme(themeName: string, transition?: ThemeTransition): void
}

export type UniwindConfigPublic = {
    readonly hasAdaptiveThemes: boolean
    readonly currentTheme: ThemeName

    // eslint-disable-next-line @typescript-eslint/no-redundant-type-constituents
    setTheme(themeName: ThemeName | 'system', transition?: ThemeTransition): void
}
