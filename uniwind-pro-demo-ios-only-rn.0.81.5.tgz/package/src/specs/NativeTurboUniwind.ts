import{TurboModuleRegistry as e}from"react-native";e.get("Uniwind");
