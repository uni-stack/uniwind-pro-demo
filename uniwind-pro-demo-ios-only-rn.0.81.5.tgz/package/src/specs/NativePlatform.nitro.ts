import { HybridObject } from 'react-native-nitro-modules'
import { UniwindRuntimeCurrent } from './UniwindRuntime.nitro'

export enum StyleDependency {
    ColorScheme = 1,
    Theme = 2,
    Dimensions = 3,
    Orientation = 4,
    Insets = 5,
    FontScale = 6,
    Rtl = 7,
    AdaptiveThemes = 8,
}

export enum ThemeTransitionPreset {
    None = 0,
    Fade = 1,
    SlideRightToLeft = 2,
    SlideLeftToRight = 3,
    CircleTopRight = 4,
    CircleTopLeft = 5,
    CircleBottomRight = 6,
    CircleBottomLeft = 7,
    CircleCenter = 8,
    Blur = 9,
    BlurRightToLeft = 10,
    BlurLeftToRight = 11,
}

export enum AppearanceOverride {
    Unspecified = 0,
    Light = 1,
    Dark = 2,
}

export enum RuntimeChangeSource {
    Native = 0,
    User = 1,
}

export type ThemeConfig = {
    prefersAdaptiveThemes: boolean
    currentThemeName: string
    themeNames: Array<string>
}

// represents any native API that can communicate with Uniwind
// not available from JS
export interface NativePlatform extends HybridObject<{ ios: 'swift'; android: 'kotlin' }> {
    getThemeConfig(): ThemeConfig
    setTheme(theme: string): void
    onThemeChanged(forTheme: string): void
    registerExtraThemes(themes: Array<string>): void
    getCurrent(): UniwindRuntimeCurrent
    addRuntimeChangeListener(
        listener: (dependencies: Array<StyleDependency>, runtime: UniwindRuntimeCurrent, source: RuntimeChangeSource) => void,
    ): void
    prepareTransition(type: ThemeTransitionPreset, targetTheme: string): void
    animateTransition(appearance: AppearanceOverride, preAnimationCallback: () => void): void
    cancelTransition(): void
}
