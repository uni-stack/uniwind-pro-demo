export const stringifyThemes=(r=[])=>`[${r.map(i=>`'${i}'`).join(", ")}]`;
